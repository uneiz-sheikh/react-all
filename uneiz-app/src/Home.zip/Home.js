import React, { useState } from 'react';
import Banner from './Banner';
function Home()
{
    const [appname,setAppname] = useState('Shopping Website');
    const changename = () =>
    {
        setAppname('Thank visit again');
    }
    return(
        <>
            <h1 onClick={() => changename()}>Home Pag {appname}</h1>
            <Banner appInfo={appname}></Banner>
        </>
    )
}

export default Home;