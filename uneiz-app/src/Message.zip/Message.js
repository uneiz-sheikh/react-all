
import React,{ memo } from "react";

function Message()
{
    console.log("Message");
    return(
        
        <>
            <h1>Message Page</h1>
        </>
    )
}

export default memo(Message);