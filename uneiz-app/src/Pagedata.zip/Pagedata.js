import React, { useState } from "react";
import Message from "./Message";

function Project()
{
    const [count,setCount] = useState(0);
    const counterchange = () =>
    {
        let countVal = count;
        countVal = countVal +1;
        setCount(countVal++);
    }
    return(
        <>
            <h1 onClick={() => counterchange()} >Count : {count}</h1>
            <Message></Message>
        </>
    )
}

export default Project;